"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-25"
-------------------------------------------------------
"""
# Imports
from functions import stack_split_alt
# Constants

call = stack_split_alt([1, 2, 3, 4, 5, 6])
print(call)
