"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-26"
-------------------------------------------------------
"""
# Imports
from functions import reroute
# Constants
values_out = reroute('SSXSXX', [1, 2, 3])
print(values_out)
