"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-26"
-------------------------------------------------------
"""
# Imports
from functions import stack_reverse
# Constants

call = stack_reverse([1, 2, 3, 4, 5])
print(call)
