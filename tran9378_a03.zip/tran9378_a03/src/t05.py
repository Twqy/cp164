"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-26"
-------------------------------------------------------
"""
# Imports
from functions import postfix
from Stack_array import Stack
# Constants

s = Stack()
first, second = postfix('(4 + 5) * 12 - 2 * 3')
print(first, second)
