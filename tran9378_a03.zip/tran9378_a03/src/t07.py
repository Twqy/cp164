"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-26"
-------------------------------------------------------
"""
# Imports
from functions import is_mirror_stack
# Constants

call = is_mirror_stack('mumma', 'mum', 'm')
print(call)
