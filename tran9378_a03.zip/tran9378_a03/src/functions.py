"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-26"
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack
from enum import Enum
# Constants
OPERATORS = "+-*/"
MIRRORED = Enum('MIRRORED',
                {'IS_MIRRORED': "is a mirror", 'TOO_MANY_LEFT': "too many characters in L",
                 'TOO_MANY_RIGHT': "too many characters in R", 'MISMATCHED': "L and R don't match",
                 'INVALID_CHAR': "invalid character", 'NOT_MIRRORED': "no mirror character"})


def stack_split_alt(source):  # t01 done
    """
    -------------------------------------------------------
    Splits the source stack into separate target stacks.
    When finished source stack is empty. Values are
    pushed alternately onto the returned target stacks.
    Use: target1, target2 = stack_split_alt(source)
    -------------------------------------------------------
    Parameters:
        source - the stack to split into two parts (Stack)
    Returns:
        target1 - contains alternating values from source (Stack)
        target2 - contains other alternating values from source (Stack)
    -------------------------------------------------------
    """
    target1 = []
    target2 = []
    i = 1
    while len(source) != 0:
        if i % 2 != 0:
            target1.append(source.pop())
        else:
            target2.append(source.pop())
        i = i + 1
    return target1, target2


def stack_reverse(source):
    """
    -------------------------------------------------------
    Reverses the contents of a stack.
    Use: stack_reverse(source)
    -------------------------------------------------------
    Parameters:
        source - a Stack (Stack)
    Returns:
        None
    -------------------------------------------------------
    """
    reverse = []
    while len(source) != 0:
        reverse.append(source.pop())
    print(reverse)
    return


def postfix(string):
    """
    -------------------------------------------------------
    Evaluates a postfix expression.
    Use: answer = postfix(string)
    -------------------------------------------------------
    Parameters:
        string - the postfix string to evaluate (str)
    Returns:
        answer - the result of evaluating string (float)
    -------------------------------------------------------
    """
    s = Stack()

    split = string.split(' ')
    for i in split:
        for i in OPERATORS:
            first = s.pop()
            second = s.pop()
            if i == OPERATORS[0]:
                value = first + second
            elif i == OPERATORS[1]:
                value = first - second
            elif i == OPERATORS[-2]:
                value = first * second
            elif i == OPERATORS[-1]:
                value = first / second
            s.push(value)
        else:
            s.push(int(i))
    answer = s.pop()
    return answer


def reroute(opstring, values_in):
    """
    -------------------------------------------------------
    Reroutes values in a list according to a operating string and
    returns a new list of values. values_in is unchanged.
    In opstring, 'S' means push onto stack,
    'X' means pop from stack into values_out.
    Use: values_out = reroute(opstring, values_in)
    -------------------------------------------------------
    Parameters:
        opstring - String containing only 'S' and 'X's (str)
        values_in - A valid list (list of ?)
    Returns:
        values_out - if opstring is valid then values_out contains a
            reordered version of values_in, otherwise returns
            None (list of ?)
    -------------------------------------------------------
    """
    stack = []
    values_out = []
    index = 0
    for i in opstring:
        if i == 'S':
            if index < len(values_in):
                stack.append(values_in[index])
                index += 1
            else:
                values_out = None
        elif i == 'X':
            if stack:
                values_out.append(stack.pop())
            else:
                values_out = None
        else:
            values_out = None
    return values_out


def is_mirror_stack(string, valid_chars, m):
    """
    -------------------------------------------------------
    Determines if string is a mirror of characters in valid_chars around the pivot m.
    A mirror is of the form LmR, where L is the reverse of R, and L and R
    contain only characters in valid_chars.
    Use: mirror = is_mirror_stack(string, valid_chars, m)
    -------------------------------------------------------
    Parameters:
        string - a string (str)
        valid_chars - a string of valid characters (str)
        m - the mirror pivot string (str - one character not in valid_chars)
    Returns:
        mirror - the state of the string (Enum MIRRORED)
    -------------------------------------------------------
    """
    stack_L = []
    stack_R = []
    pivot_index = string.index(m)
    L = string[:pivot_index]
    R = string[pivot_index + 1:]
    if len(L) != len(R):
        if len(L) > len(R):
            mirror = MIRRORED.TOO_MANY_LEFT
        else:
            mirror = MIRRORED.TOO_MANY_RIGHT
    for i in L:
        if i not in valid_chars:
            mirror = MIRRORED.INVALID_CHAR
        stack_L.append(i)
    for i in R:
        if i not in valid_chars:
            mirror = MIRRORED.INVALID_CHAR
        stack_R.append(i)
    while stack_L:
        char_L = stack_L.pop()
        char_R = stack_R.pop(0)
        if char_L != char_R:
            mirror = MIRRORED.MISMATCHED
    print(f'mirror: {mirror.value}')
    return mirror
