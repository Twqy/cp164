"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-09"
-------------------------------------------------------
"""
# Imports
from Sorted_List_array import Sorted_List
from movie_utilities import read_movie
# Constants

fv = open('movies.txt', 'r')
movies = read_movie(fv)
movies1 = []
for i in movies:
    movies1.append(i)

l = Sorted_List()

l.append([5, 10, 5, 5, 5, 20])

l.clean()

l.combine([1, 3, 5, 7], [2, 4, 6, 8])

l.intersection(['a', 'b', 'c'], ['a', 'tree', 'egg'])

l.prepend(5)

l.remove_front

l.remove_many

l.split()

l.split_alt()

l.union(['a', 'b', 'c'], [1, 2, 3, 4, 5])
