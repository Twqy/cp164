"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-07-14"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST
# Constants

print('Testing BST#node_counts')
print('\n\nEmpty BST')
bst = BST()

zero, one, two = bst.node_counts()
print("Nodes w/ ZERO children: {}\tExpected: {}".format(zero, 0))
print("Nodes w/ ONE children: {}\t\tExpected: {}".format(one, 0))
print("Nodes w/ TWO children: {}\t\tExpected: {}".format(two, 0))

print('\n\nNon-empty BST with only two nodes')
bst = BST()
for val in [2, 4]:
    bst.insert(val)
zero, one, two = bst.node_counts()
print("Nodes w/ ZERO children: {}\tExpected: {}".format(zero, 1))
print("Nodes w/ ONE child: {}\t\tExpected: {}".format(one, 1))
print("Nodes w/ TWO children: {}\t\tExpected: {}".format(two, 0))
