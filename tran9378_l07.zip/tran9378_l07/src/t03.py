"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-22"
-------------------------------------------------------
"""
# Imports
from List_linked import List
# Constants

list = List()
values = [2, 4, 6, 8]
for i in values:
    list.append(i)
input = 5
x, y, z = list._linear_search_r(input)

print("Current:{}".format(y._value if y is not None else y))
print("Previous:{}".format(x._value if x is not None else x))
print("Index:{}".format(z))

x = list.split_alt_r()
print(x)
