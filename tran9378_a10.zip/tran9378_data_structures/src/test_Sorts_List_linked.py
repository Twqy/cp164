"""
-------------------------------------------------------
Tests various linked sorting functions.
-------------------------------------------------------
Author:  RyanTran
ID:      169069378
Email:   tran9378@wlu.ca
Section: CP164 C
__updated__ = "2024-07-13"
-------------------------------------------------------
"""
# Imports
import random

from List_linked import List
from Number import Number
from Sorts_List_linked import Sorts

# Constants
SIZE = 100  # Size of array to sort.
XRANGE = 1000  # Range of values in random arrays to sort.
TESTS = 100  # Number of random arrays to generate.

SORTS = (
    ('Bubble Sort', Sorts.bubble_sort),
    ('Insertion Sort', Sorts.insertion_sort),
    ('Merge Sort', Sorts.merge_sort),
    ('Quick Sort', Sorts.quick_sort),
    ('Selection Sort', Sorts.selection_sort),
)


def create_sorted():
    """
    -------------------------------------------------------
    Creates a sorted List of Number objects.
    Use: values = create_sorted()
    -------------------------------------------------------
    Returns:
        values - a sorted list of SIZE Number objects (List of Number)
    -------------------------------------------------------
    """

    # your code here
    values = List()
    for i in range(SIZE):
        values.append(Number(i))
    return values


def create_reversed():
    """
    -------------------------------------------------------
    Create a reversed List of Number objects.
    Use: values = create_reversed()
    -------------------------------------------------------
    Returns:
        values - a reversed list of SIZE Number objects (List of Number)
    -------------------------------------------------------
    """

    # your code here
    values = List()
    for i in range(SIZE - 1, -1, -1):
        values.append(Number(i))
    return values


def create_randoms():
    """
    -------------------------------------------------------
    Create a 2D list of Number objects with TESTS rows and
    SIZE columns of values between 0 and XRANGE.
    Use: lists = create_randoms()
    -------------------------------------------------------
    Returns:
        lists - TESTS lists of SIZE Number objects containing
            values between 0 and XRANGE (list of List of Number)
    -------------------------------------------------------
    """

    # your code here
    lists = []
    for i in range(TESTS):
        random_list = List()
        for i in range(SIZE):
            random_list.append(Number(random.randint(0, XRANGE - 1)))
        lists.append(random_list)
    return lists


def test_sort(title, func):
    """
    -------------------------------------------------------
    Tests a sort function with Number data and prints the number 
    of comparisons necessary to sort an array:
    in order, in reverse order, and a list of Lists in random order.
    Use: test_sort(title, func)
    -------------------------------------------------------
    Parameters:
        title - name of the sorting function to call (str)
        func - the actual sorting function to call (function)
    Returns:
        None
    -------------------------------------------------------
    """

    # your code here
    sorted_values = create_sorted()
    reversed_values = create_reversed()
    random_values = create_randoms()

    Number.comparisons = 0
    func(sorted_values)
    sorted_comparisons = Number.comparisons

    Number.comparisons = 0
    func(reversed_values)
    reversed_comparisons = Number.comparisons

    # Sort the random Lists
    random_comparisons = 0
    for values in random_values:
        Number.comparisons = 0
        func(values)
        random_comparisons += Number.comparisons
    random_comparisons //= TESTS

    # Print
    print(f"{title:<14} {sorted_comparisons:>8} {reversed_comparisons:>8} {random_comparisons:>8}")
