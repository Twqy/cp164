"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-07-21"
-------------------------------------------------------
"""
# Imports
from Sorts_List_linked import Sorts
from List_linked import List
# Constants


def list_to_python_list(a):
    result = []
    curr = a._front
    while curr is not None:
        result.append(curr._value)
        curr = curr._next
    return result


def python_list_to_list(py_list):
    lst = List()
    for value in py_list:
        lst.append(value)
    return lst


print('Testing Sorts.radix_sort\n')
print('\nEmpty list')
a = List()
Sorts.radix_sort(a)
sorted_list = list_to_python_list(a)
print("Sorted list: {}\tExpected: {}".format(sorted_list, []))
