"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-07-21"
-------------------------------------------------------
"""
# Imports
from Deque_linked import Deque
from Sorts_Deque_linked import Sorts
# Constants


def print_deque(d):
    current = d._front
    values = []
    while current is not None:
        values.append(current._value)
        current = current._next
    print(values)


print('Testing Sorts.gnome_sort')

print('\nEmpty Deque')
d1 = Deque()
print("Original Deque:")
print_deque(d1)
Sorts.gnome_sort(d1)
print("Sorted Deque:")
print_deque(d1)
print("Expected: []")

print('\nSingle element Deque')
d2 = Deque()
d2.insert_rear(5)
print("Original Deque:")
print_deque(d2)
Sorts.gnome_sort(d2)
print("Sorted Deque:")
print_deque(d2)
print("Expected: [5]")

print('\nSorted Deque')
d3 = Deque()
for value in [1, 2, 3, 4, 5]:
    d3.insert_rear(value)
print("Original Deque:")
print_deque(d3)
Sorts.gnome_sort(d3)
print("Sorted Deque:")
print_deque(d3)
print("Expected: [1, 2, 3, 4, 5]")
