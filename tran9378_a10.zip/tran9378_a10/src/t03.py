"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-07-21"
-------------------------------------------------------
"""
# Imports
from Sorts_array import Sorts

# Constants

print('Testing Sorts.gnome_sort')

print('\nEmpty list')
a = []
Sorts.gnome_sort(a)
print("Sorted list: {}\tExpected: {}".format(a, []))

print('\nSingle element list')
a = [5]
Sorts.gnome_sort(a)
print("Sorted list: {}\tExpected: {}".format(a, [5]))

print('\nSorted list')
a = [1, 2, 3, 4, 5]
Sorts.gnome_sort(a)
print("Sorted list: {}\tExpected: {}".format(a, [1, 2, 3, 4, 5]))

print('\nReverse sorted list')
a = [5, 4, 3, 2, 1]
Sorts.gnome_sort(a)
print("Sorted list: {}\tExpected: {}".format(a, [1, 2, 3, 4, 5]))

print('\nUnsorted list')
a = [170, 45, 75, 90, 802, 24, 2, 66]
Sorts.gnome_sort(a)
print("Sorted list: {}\tExpected: {}".format(
    a, [2, 24, 45, 66, 75, 90, 170, 802]))

print('\nList with duplicates')
a = [3, 3, 2, 1, 2, 3, 1, 2]
Sorts.gnome_sort(a)
print("Sorted list: {}\tExpected: {}".format(a, [1, 1, 2, 2, 2, 3, 3, 3]))
