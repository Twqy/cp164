"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-02"
-------------------------------------------------------
"""
# Imports
from Queue_circular import Queue
# Constants

q1 = Queue()
q1.insert(1)
Queue()
q2 = Queue()
q2.insert(1)
Queue()

print(q1 == q2)
