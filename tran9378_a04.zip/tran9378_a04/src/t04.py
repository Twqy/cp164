"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-02"
-------------------------------------------------------
"""
# Imports
from Queue_array import Queue
# Constants

q1 = Queue()
q1.insert(5)
q2 = Queue()
q2.insert(7)
target = Queue()
target.combine(q1, q2)
for i in target:
    print(i)
