"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-02"
-------------------------------------------------------
"""
# Imports
from Priority_Queue_array import Priority_Queue
# Constants

pq = Priority_Queue()
pq.insert(10)
pq.insert(5)
key = 7
target1, taret2 = pq.split_key(key)

print("Values greater than key:")
for i in target1:
    print(i)

print("Values less than or equal to key:")
for i in taret2:
    print(i)
