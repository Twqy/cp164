"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-02"
-------------------------------------------------------
"""
# Imports
from functions import queue_combine
from Priority_Queue_array import Priority_Queue
# Constants

src1 = Priority_Queue()
src2 = Priority_Queue()
src1.insert(5)
src1.insert(6)
src2.insert(7)
src2.insert(8)
target = queue_combine(src1, src2)
for i in target:
    print(i)
