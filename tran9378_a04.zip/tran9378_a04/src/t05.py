"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-02"
-------------------------------------------------------
"""
# Imports
from functions import pq_split_key
from Priority_Queue_array import Priority_Queue
# Constants

pq = Priority_Queue()
pq.insert(9)
pq.insert(5)
key = 6
target1, target2 = pq_split_key(pq, key)
print('Values greater than key')
for i in target1:
    print(i)
print('Values less than key')
for i in target2:
    print(i)
