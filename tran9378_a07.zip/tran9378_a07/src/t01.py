"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-30"
-------------------------------------------------------
"""
# Imports
from Sorted_List_linked import Sorted_List
# Constants

lst = Sorted_List()


lst.insert(5)
assert lst._front._value == 5
lst.insert(3)
assert lst._front._value == 3
assert lst._front._next._value == 5
print("Insert method test passed.")


lst.remove(3)
assert lst._front._value == 5
assert lst._front._next is None
print("Remove method test passed.")


lst1 = Sorted_List()
lst2 = Sorted_List()
lst1.insert(1)
lst1.insert(3)
lst1.insert(5)
lst2.insert(2)
lst2.insert(3)
lst2.insert(5)
lst.intersection(lst1, lst2)
assert lst._front._value == 3
assert lst._front._next._value == 5

print("Intersection method test passed.")
print("hi")
