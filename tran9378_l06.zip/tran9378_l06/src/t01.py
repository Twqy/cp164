"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-15"
-------------------------------------------------------
"""
# Imports
from List_linked import List
from List_linked import _List_Node
# Constants

ll = List()
vals = ['apple', 'banana', 'cherry', 'date']
for val in vals:
    ll.append(val)
print("Append")
check = []
for node_val in ll:
    check.append(node_val)
print("List contents: {}".format(check))
print("\nPrepend")
check = []
to_prepend = 'apricot'
ll.prepend(to_prepend)
for val in ll:
    check.append(val)
print("List contents: {}".format(check))
print("\nInsert")
print("Positive index within range")
check = []
to_insert = 'elderberry'
ll.insert(3, to_insert)
for val in ll:
    check.append(val)
print("List contents: {}".format(check))
print("Negative index within range")
check = []
to_insert = 'fig'
ll.insert(-2, to_insert)
for val in ll:
    check.append(val)
print("List contents: {}".format(check))
