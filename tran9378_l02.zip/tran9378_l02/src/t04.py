"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-16"
-------------------------------------------------------
"""
# Imports
from utilities import stack_test
from Stack_array import Stack
# Constants

call = stack_test([1, 2, 3])
print(call)
