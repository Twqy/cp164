"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-16"
-------------------------------------------------------
"""
# Imports
from utilities import array_to_stack
from Stack_array import Stack
# Constants

values = [0, 1, 2, 3, 4]
stack = Stack()

call = array_to_stack(stack, values)
print(call)

print(f'{stack._values}')
