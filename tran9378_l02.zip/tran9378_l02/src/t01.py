"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-16"
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack
# Constants

stack = Stack()
for i in range(1, 5):  # makes the values 1-4
    stack._values.append(i)

empty = stack.is_empty()
print(f'Empty: {empty}')

push = stack.push(5)
print(f'Push: {stack._values}')

pop = stack.pop()
print(f'Pop: {stack._values}')

peek = stack.peek()
print(f'Peek: {peek}')
