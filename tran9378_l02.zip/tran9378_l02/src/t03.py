"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-16"
-------------------------------------------------------
"""
# Imports
from utilities import stack_to_array
from Stack_array import Stack
# Constants

stack = Stack()
target = []

call = stack_to_array(stack, target)
print(call)
print(f'{stack._values}')
