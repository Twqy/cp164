"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-07-07"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST
# Constants

tree = BST()
tree.insert(1)
tree.insert(2)
tree.insert(5)
tree.insert(4)
print(tree.levelorder())
