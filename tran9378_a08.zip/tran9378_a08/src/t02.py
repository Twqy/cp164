"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-07-07"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST
from Letter import fill_letter_bst
from functions import do_comparisons, comparison_total, letter_table
# Constant
DATA1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
DATA2 = "MFTCJPWADHKNRUYBEIGLOQSVXZ"
DATA3 = "ETAOINSHRDLUCMPFYWGBVKJXZQ"
FILE_NAME = "miserables.txt"

bst1 = BST()
bst2 = BST()
bst3 = BST()
fill_letter_bst(bst1, DATA1)
fill_letter_bst(bst2, DATA2)
fill_letter_bst(bst3, DATA3)

with open(FILE_NAME, "r", encoding="utf-8") as file_variable:
    do_comparisons(file_variable, bst1)
    t1 = comparison_total(bst1)

with open(FILE_NAME, "r", encoding="utf-8") as file_variable:
    do_comparisons(file_variable, bst2)
    t2 = comparison_total(bst2)

with open(FILE_NAME, "r", encoding="utf-8") as file_variable:
    do_comparisons(file_variable, bst3)
    t3 = comparison_total(bst3)

# Print comparison results
print("Comparing by order: ABCDEFGHIJKLMNOPQRSTUVWXYZ")
print("{}".format(t1))
print("------------------------------------------------------------")
print("Comparing by order: MFTCJPWADHKNRUYBEIGLOQSVXZ")
print("{}".format(t2))
print("------------------------------------------------------------")
print("Comparing by order: ETAOINSHRDLUCMPFYWGBVKJXZQ")
print("{}".format(t3))
print("------------------------------------------------------------")

# Print letter table for bst1
letter_table(bst1)
