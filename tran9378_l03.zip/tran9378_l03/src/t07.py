"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-23"
-------------------------------------------------------
"""
# Imports
from movie_utilities import read_movies
from utilities import priority_queue_test
# Constants

fv = open('movies.txt', 'r')
movies = read_movies(fv)
priority_queue_test(movies)
