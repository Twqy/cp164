"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-23"
-------------------------------------------------------
"""
# Imports
from Priority_Queue_array import Priority_Queue
# Constants

pq = Priority_Queue()
values = [22, 33, 11, 55, 44]
for i in values:
    pq.insert(i)
