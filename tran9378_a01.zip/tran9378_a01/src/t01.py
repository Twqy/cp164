"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author: Ryan Tran
ID:169069378
Email: tran9378@mylaurier.ca
__updated__ = "2024-05-11"
-------------------------------------------------------
"""
# Imports
from functions import list_subtraction
# Constants

list = list_subtraction([5, 5, 4, 5], [5])
print(list)
