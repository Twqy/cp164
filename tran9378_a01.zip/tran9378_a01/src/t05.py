"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author: Ryan Tran
ID:169069378
Email: tran9378@mylaurier.ca
__updated__ = "2024-05-11"
-------------------------------------------------------
"""
# Imports
from functions import matrix_flatten
# Constants

call = matrix_flatten([['a', 'b'], ['x', 'z'], ['e', 'f']])
print(call)
