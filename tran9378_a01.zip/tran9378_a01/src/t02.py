"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author: Ryan Tran
ID:169069378
Email: tran9378@mylaurier.ca
__updated__ = "2024-05-11"
-------------------------------------------------------
"""
# Imports
from functions import file_analyze
# Constants

with open('movies.txt', 'r') as file:
    upp, low, dig, whi, rem = file_analyze(file)

print('Uppercase letters:', upp)
print('Lowercase letters:', low)
print('Digits:', dig)
print('Whitespace characters:', whi)
print('Remaining characters:', rem)
