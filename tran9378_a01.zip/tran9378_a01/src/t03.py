"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author: Ryan Tran
ID:169069378
Email: tran9378@mylaurier.ca
__updated__ = "2024-05-11"
-------------------------------------------------------
"""
# Imports
from functions import is_palindrome
# Constants

call = is_palindrome('racecar')
print(call)
