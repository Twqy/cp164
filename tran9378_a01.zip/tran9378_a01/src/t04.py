"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author: Ryan Tran
ID:169069378
Email: tran9378@mylaurier.ca
__updated__ = "2024-05-11"
-------------------------------------------------------
"""
# Imports
from functions import matrix_transpose
# Constants

call = matrix_transpose([[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]])
print(call)
