"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-07-13"
-------------------------------------------------------
"""
# Imports
from test_Sorts_array import test_sort, SORTS, SIZE
# Constants

SEP = "-" * 15 + " " + "-" * 8 + " " + "-" * 8 + " " + "-" * 7 + "\t" + "-" * 8 + " " + "-" * 8 + " " + "-" * 6
print(SEP)

for i in SORTS:
    title = i[0]
    sort_func = i[1]
    test_sort(title, sort_func)
