"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-07-13"
-------------------------------------------------------
"""
# Imports
from test_Sorts_array import test_sort, SORTS
# Constants

for i in SORTS:
    test_sort(i[0], i[1])
