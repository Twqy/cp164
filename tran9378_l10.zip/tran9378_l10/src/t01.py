"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-07-13"
-------------------------------------------------------
"""
# Imports
from test_Sorts_array import create_sorted, create_reversed, \
    create_randoms
# Constants

sorted_list = create_sorted()
reversed_list = create_reversed()
random_lists = create_randoms()

print("Sorted:")
for num in sorted_list:
    print(num)

print("Reversed:")
for num in reversed_list:
    print(num)

print("Random Lists:")
print("[", end='')
for lst in random_lists:
    print("[", end='')
    for num in lst:
        print(num, end=', ')
    print("],")
print("]")
