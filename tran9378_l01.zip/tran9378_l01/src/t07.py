"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-10"
-------------------------------------------------------
"""
# Imports
from Movie_utilities import read_movies
# Constants

fv = open('movies.txt', 'r')
movies = read_movies(fv)
fv.close()

for movie in movies:
    print(f'{movie}\n---------------------------------------------')
