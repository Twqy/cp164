"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-10"
-------------------------------------------------------
"""
# Imports
from Movie_utilities import get_movie
# Constants

movie = get_movie()
print(movie)
