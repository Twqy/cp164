"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-10"
-------------------------------------------------------
"""
# Imports
from Movie_utilities import read_movie
# Constants

movie_info = 'Dellamorte Dellamore|1994|Michele Soavi|7.2|3,4,5,8'
movie = read_movie(movie_info)
print(movie)
