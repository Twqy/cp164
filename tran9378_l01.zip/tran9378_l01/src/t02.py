"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-10"
-------------------------------------------------------
"""
# Imports
from Movie import Movie
# Constants

title = "skibidi toilet"
year = 2069
director = "Kai Cenat"
rating = 6.9
genres = [3, 4, 5, 8]

my_movie = Movie(title, year, director, rating, genres)
list = my_movie.genres_list_string()
print(list)
