"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-10"
-------------------------------------------------------
"""
# Imports
from Movie import Movie

# Constants

genre = genres_menu()
print(genre)
