"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-01"
-------------------------------------------------------
"""
# Imports
from utilities import list_test
from movie import Movie
# Constants


def main():
    first = Movie('Z', 1969, 'Costa-Gavras', 8.2, 2)
    second = Movie('Wonder Women', 2017, 'Patty Jenkins', 8.1, 1)
    third = Movie('Zulu', 2013, 'Jerome Salle', 6.7, 2)
    source = [first, second, third]
    source2 = [1, 2, 3]
    list_test(source)


main()
