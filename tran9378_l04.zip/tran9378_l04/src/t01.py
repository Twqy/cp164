"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-01"
-------------------------------------------------------
"""
# Imports
from movie import Movie
# Constants


def main():
    key = Movie(None, 2010, None, None, None)
    print(key)
main()
