"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-29"
-------------------------------------------------------
"""
# Imports
from List_array import List
from utilities import array_to_list, list_to_array
# Constants

llist = List()
array = [1, 2, 3]
array_to_list(llist, array)
for i in llist:
    print(i)

target = []
list_to_array(llist, target)
print(target)
