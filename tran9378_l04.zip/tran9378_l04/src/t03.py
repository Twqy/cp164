"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-01"
-------------------------------------------------------
"""
# Imports
from List_array import List
# Constants


def main():
    l = List()
    l.append(99)
    a = l.remove(99)
    print(a)
main()
