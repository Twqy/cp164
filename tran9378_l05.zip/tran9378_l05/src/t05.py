"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-06"
-------------------------------------------------------
"""
# Imports
from functions import is_palindrome
# Constants
