"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-06"
-------------------------------------------------------
"""
# Imports
from functions import recurse
# Constants

x = int(0)
y = int(1)
call = recurse(x, y)
print(call)
