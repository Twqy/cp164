"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-06-07"
-------------------------------------------------------
"""
# Imports
from functions import to_power
# Constants

call = to_power(int(5), int(2))
print(call)
