"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-16"
-------------------------------------------------------
"""
# Imports
from movie_utilities import read_movies, get_by_genre
# Constants
genre = 0

fv = open('movies.txt', 'r')
movie = read_movies(fv)
gmovies = get_by_genre(movie, genre)

for i in gmovies:
    print(i)
