"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-16"
-------------------------------------------------------
"""
# Imports
from movie_utilities import read_movies, get_by_year
# Constants
year = int(2007)

fv = open('movies.txt', 'r')
movie = read_movies(fv)
ymovies = get_by_year(movie, year)

for i in ymovies:
    print(i)
