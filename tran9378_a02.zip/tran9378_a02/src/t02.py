"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-16"
-------------------------------------------------------
"""
# Imports
from movie_utilities import read_movies, get_by_rating
# Constants
rating = float(8.1)

fv = open('movies.txt', 'r')
movie = read_movies(fv)
rmovies = get_by_rating(movie, rating)

for i in rmovies:
    print(i)
