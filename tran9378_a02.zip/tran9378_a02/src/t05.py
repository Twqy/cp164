"""
-------------------------------------------------------
CP164
-------------------------------------------------------
Author:Ryan Tran
ID:169069378
Email:tran9378@mylaurier.ca
__updated__ = "2024-05-17"
-------------------------------------------------------
"""
# Imports
from movie_utilities import read_movies, genre_counts
# Constants
counts = 0

fv = open('movies.txt', 'r')
movie = read_movies(fv)
counts = genre_counts(movie)

for i in counts:
    print(i, end=',')
